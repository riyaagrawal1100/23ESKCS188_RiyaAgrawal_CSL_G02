"""Classical cipher encryption and automated cryptanalysis utilities.

The implementation assumes English plaintext and preserves spaces/punctuation.
Only A-Z letters participate in encryption and statistical analysis.
"""
from collections import Counter
import re

ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
ENGLISH_FREQ = {
    "A": 8.167, "B": 1.492, "C": 2.782, "D": 4.253, "E": 12.702,
    "F": 2.228, "G": 2.015, "H": 6.094, "I": 6.966, "J": 0.153,
    "K": 0.772, "L": 4.025, "M": 2.406, "N": 6.749, "O": 7.507,
    "P": 1.929, "Q": 0.095, "R": 5.987, "S": 6.327, "T": 9.056,
    "U": 2.758, "V": 0.978, "W": 2.360, "X": 0.150, "Y": 1.974,
    "Z": 0.074,
}

def letters_only(text):
    return "".join(ch for ch in text.upper() if ch in ALPHABET)

def caesar_encrypt(text, shift):
    result = []
    for ch in text:
        if ch.upper() in ALPHABET:
            base = ord("A") if ch.isupper() else ord("a")
            result.append(chr((ord(ch) - base + shift) % 26 + base))
        else:
            result.append(ch)
    return "".join(result)

def caesar_decrypt(text, shift):
    return caesar_encrypt(text, -shift)

def vigenere_encrypt(text, key):
    key = letters_only(key)
    if not key:
        raise ValueError("The Vigenere key must contain at least one A-Z letter.")
    result, j = [], 0
    for ch in text:
        if ch.upper() in ALPHABET:
            shift = ord(key[j % len(key)]) - ord("A")
            base = ord("A") if ch.isupper() else ord("a")
            result.append(chr((ord(ch) - base + shift) % 26 + base))
            j += 1
        else:
            result.append(ch)
    return "".join(result)

def vigenere_decrypt(text, key):
    key = letters_only(key)
    if not key:
        raise ValueError("The Vigenere key must contain at least one A-Z letter.")
    result, j = [], 0
    for ch in text:
        if ch.upper() in ALPHABET:
            shift = ord(key[j % len(key)]) - ord("A")
            base = ord("A") if ch.isupper() else ord("a")
            result.append(chr((ord(ch) - base - shift) % 26 + base))
            j += 1
        else:
            result.append(ch)
    return "".join(result)

def chi_squared(text):
    """Return Pearson chi-square distance from standard English frequencies."""
    clean = letters_only(text)
    n = len(clean)
    if n == 0:
        return float("inf")
    counts = Counter(clean)
    score = 0.0
    for letter, percentage in ENGLISH_FREQ.items():
        expected = n * percentage / 100.0
        observed = counts.get(letter, 0)
        score += (observed - expected) ** 2 / expected
    return score

def crack_caesar(ciphertext):
    """Try all 26 Caesar shifts and return the lowest chi-square candidate."""
    candidates = []
    for shift in range(26):
        plain = caesar_decrypt(ciphertext, shift)
        candidates.append((chi_squared(plain), shift, plain))
    score, shift, plaintext = min(candidates, key=lambda item: item[0])
    return {"key": shift, "plaintext": plaintext, "score": score}

def index_of_coincidence(text):
    clean = letters_only(text)
    n = len(clean)
    if n < 2:
        return 0.0
    counts = Counter(clean)
    return sum(v * (v - 1) for v in counts.values()) / (n * (n - 1))

def kasiski_distances(ciphertext, min_length=3, max_length=5):
    """Find distances between repeated n-grams (usually 3-5 letters)."""
    clean = letters_only(ciphertext)
    distances = []
    for size in range(min_length, max_length + 1):
        positions = {}
        for i in range(len(clean) - size + 1):
            gram = clean[i:i + size]
            positions.setdefault(gram, []).append(i)
        for places in positions.values():
            if len(places) > 1:
                for a in range(len(places) - 1):
                    for b in range(a + 1, len(places)):
                        distances.append(places[b] - places[a])
    return distances

def _factors(number, maximum):
    return [k for k in range(2, maximum + 1) if number % k == 0]

def estimate_vigenere_key_length(ciphertext, max_key_length=16):
    """Rank likely key lengths using Kasiski factor votes and average IC."""
    clean = letters_only(ciphertext)
    if len(clean) < 20:
        return 1
    distances = kasiski_distances(clean)
    votes = Counter()
    for distance in distances:
        for factor in _factors(distance, max_key_length):
            votes[factor] += 1

    ranked = []
    for length in range(1, min(max_key_length, max(1, len(clean) // 2)) + 1):
        columns = [clean[i::length] for i in range(length)]
        avg_ic = sum(index_of_coincidence(col) for col in columns) / length
        # English-like columns tend toward a higher IC (~0.066); random text ~0.038.
        ic_score = abs(avg_ic - 0.066)
        # Kasiski votes help prioritize lengths that divide repeated-gram distances.
        vote_bonus = votes[length]
        combined = ic_score - (0.002 * vote_bonus)
        ranked.append((combined, length, avg_ic, vote_bonus))
    ranked.sort()
    return ranked[0][1]

def _best_caesar_shift_for_column(column):
    best_shift, best_score = 0, float("inf")
    for shift in range(26):
        decrypted = caesar_decrypt(column, shift)
        score = chi_squared(decrypted)
        if score < best_score:
            best_shift, best_score = shift, score
    return best_shift

def crack_vigenere(ciphertext, max_key_length=16, key_length=None):
    """Estimate key length, recover each key character with chi-square, decrypt."""
    clean = letters_only(ciphertext)
    if not clean:
        return {"key": "", "key_length": 0, "plaintext": ciphertext, "score": 0.0}
    length = key_length or estimate_vigenere_key_length(clean, max_key_length)
    shifts = []
    for column_index in range(length):
        column = clean[column_index::length]
        shifts.append(_best_caesar_shift_for_column(column))
    key = "".join(chr(shift + ord("A")) for shift in shifts)
    plaintext = vigenere_decrypt(ciphertext, key)
    return {
        "key": key,
        "key_length": length,
        "plaintext": plaintext,
        "score": chi_squared(plaintext),
    }

def accuracy_metrics(expected, predicted):
    """Character accuracy over A-Z letters and exact whole-message match."""
    a, b = letters_only(expected), letters_only(predicted)
    if not a:
        return {"letter_accuracy": 0.0, "exact_match": False}
    compared = min(len(a), len(b))
    correct = sum(a[i] == b[i] for i in range(compared))
    accuracy = correct / max(len(a), len(b)) * 100
    return {
        "letter_accuracy": round(accuracy, 2),
        "exact_match": a == b,
    }
