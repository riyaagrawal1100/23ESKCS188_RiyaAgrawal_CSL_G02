# CSL-G02: Automated Cryptanalysis of Caesar & Vigenere Ciphers

## 1. Project overview
This project demonstrates how classical substitution ciphers can be attacked automatically.
It supports Caesar and Vigenere encryption/decryption and attempts to recover unknown keys
using English letter-frequency statistics, chi-square scoring and Kasiski examination.

## 2. Requirements
- Python 3.9 or newer
- No third-party package is needed to run the application.
- `pytest` is optional and is used only for automated tests.

## 3. Folder structure
```text
CSL_G02_Cryptanalysis_Project/
├── src/
│   ├── main.py
│   └── cryptanalysis.py
├── data/
│   └── sample_plaintext.txt
├── tests/
│   └── test_cryptanalysis.py
├── results/
├── report.md
└── requirements.txt
```

## 4. Run the project (Windows)
Open Command Prompt or the VS Code terminal in this project folder.

### Caesar encryption
```bash
python src/main.py --cipher caesar --mode encrypt --text "HELLO WORLD" --key 3
```

### Caesar automatic cracking
```bash
python src/main.py --cipher caesar --mode crack --text "KHOOR ZRUOG"
```

### Vigenere encryption
```bash
python src/main.py --cipher vigenere --mode encrypt --text "ATTACK AT DAWN" --key LEMON
```

### Vigenere automatic cracking
Use a sufficiently long ciphertext for statistical analysis:
```bash
python src/main.py --cipher vigenere --mode crack --text "PASTE YOUR LONG CIPHERTEXT HERE" --max-key-length 16
```

If the likely key length is already known, supply it to make key recovery more reliable:
```bash
python src/main.py --cipher vigenere --mode crack --text "PASTE CIPHERTEXT" --key-length 5
```

You can also pass a text-file path instead of the text itself:
```bash
python src/main.py --cipher caesar --mode crack --text data/ciphertext.txt
```

### Run the accuracy experiment
```bash
python src/evaluate.py
```
This encrypts the bundled sample with known keys, attempts to recover them automatically,
compares the recovered letters with the original, and saves the measurements to
`results/accuracy_results.json`.

## 5. Run tests
```bash
python -m pip install -r requirements.txt
python -m pytest -v
```

## 6. Important limitations
- Statistical cracking assumes the original plaintext is mainly English.
- Very short ciphertexts do not contain enough statistical evidence.
- Vigenere key-length estimation is heuristic. Kasiski distances can suggest candidates,
  but repeated patterns may be absent or misleading.
- The automatic Vigenere method estimates the key length and then uses chi-square scoring
  on each column. For difficult text, try a longer ciphertext or provide `--key-length`.
- This is an educational demonstration, not a modern secure encryption system.
