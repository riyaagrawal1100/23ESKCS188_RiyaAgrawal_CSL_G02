"""Simple command-line interface for the CSL-G02 mini project."""
import argparse
from pathlib import Path
from cryptanalysis import (
    caesar_encrypt, caesar_decrypt, vigenere_encrypt, vigenere_decrypt,
    crack_caesar, crack_vigenere, accuracy_metrics
)

def read_text(value):
    path = Path(value)
    return path.read_text(encoding="utf-8") if path.exists() else value

def main():
    parser = argparse.ArgumentParser(
        description="Automated cryptanalysis of Caesar and Vigenere ciphers"
    )
    parser.add_argument("--cipher", choices=["caesar", "vigenere"], required=True)
    parser.add_argument("--mode", choices=["encrypt", "decrypt", "crack"], required=True)
    parser.add_argument("--text", required=True, help="Text itself or path to a UTF-8 text file")
    parser.add_argument("--key", help="Caesar shift (0-25) or Vigenere keyword")
    parser.add_argument("--max-key-length", type=int, default=16)
    parser.add_argument("--key-length", type=int, help="Optional known Vigenere key length")
    args = parser.parse_args()
    text = read_text(args.text)

    if args.mode == "crack":
        result = crack_caesar(text) if args.cipher == "caesar" else crack_vigenere(
            text, max_key_length=args.max_key_length, key_length=args.key_length
        )
        print(f"Recovered key: {result['key']}")
        if "key_length" in result:
            print(f"Estimated key length: {result['key_length']}")
        print(f"Chi-square score: {result['score']:.3f}")
        print("\nRecovered plaintext:\n")
        print(result["plaintext"])
        return

    if args.key is None:
        parser.error("--key is required for encrypt/decrypt mode")
    if args.cipher == "caesar":
        key = int(args.key)
        if not 0 <= key <= 25:
            parser.error("Caesar key must be between 0 and 25")
        output = caesar_encrypt(text, key) if args.mode == "encrypt" else caesar_decrypt(text, key)
    else:
        output = vigenere_encrypt(text, args.key) if args.mode == "encrypt" else vigenere_decrypt(text, args.key)
    print(output)

if __name__ == "__main__":
    main()
