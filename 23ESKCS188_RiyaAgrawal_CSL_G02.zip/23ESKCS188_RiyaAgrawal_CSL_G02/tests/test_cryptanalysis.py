import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cryptanalysis import (
    caesar_encrypt, caesar_decrypt, vigenere_encrypt, vigenere_decrypt,
    crack_caesar, crack_vigenere, accuracy_metrics
)

SAMPLE = (
    "THIS IS A LONGER ENGLISH MESSAGE THAT CONTAINS COMMON LETTERS "
    "AND WORDS SO THAT FREQUENCY ANALYSIS CAN IDENTIFY THE ORIGINAL TEXT. "
) * 5

def test_caesar_round_trip():
    assert caesar_decrypt(caesar_encrypt("Hello, World!", 7), 7) == "Hello, World!"

def test_vigenere_round_trip():
    assert vigenere_decrypt(vigenere_encrypt("Attack at dawn!", "LEMON"), "LEMON") == "Attack at dawn!"

def test_caesar_cracking():
    encrypted = caesar_encrypt(SAMPLE, 11)
    result = crack_caesar(encrypted)
    assert result["key"] == 11
    assert accuracy_metrics(SAMPLE, result["plaintext"])["letter_accuracy"] == 100.0

def test_vigenere_with_known_length():
    encrypted = vigenere_encrypt(SAMPLE, "LEMON")
    result = crack_vigenere(encrypted, key_length=5)
    assert result["key"] == "LEMON"
    assert accuracy_metrics(SAMPLE, result["plaintext"])["letter_accuracy"] == 100.0
