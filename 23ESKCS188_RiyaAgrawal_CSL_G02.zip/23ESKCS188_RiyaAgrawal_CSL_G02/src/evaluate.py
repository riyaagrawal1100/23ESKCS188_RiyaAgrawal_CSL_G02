"""Run reproducible accuracy experiments using the bundled sample plaintext."""
from pathlib import Path
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from cryptanalysis import (
    caesar_encrypt, vigenere_encrypt, crack_caesar, crack_vigenere,
    accuracy_metrics
)

project_root = Path(__file__).resolve().parents[1]
plaintext = (project_root / "data" / "sample_plaintext.txt").read_text(encoding="utf-8")

# Experiment 1: Caesar cipher with shift 7
caesar_ciphertext = caesar_encrypt(plaintext, 7)
caesar_result = crack_caesar(caesar_ciphertext)
caesar_metrics = accuracy_metrics(plaintext, caesar_result["plaintext"])

# Experiment 2: Vigenere cipher with keyword LEMON; key length is estimated automatically
vigenere_ciphertext = vigenere_encrypt(plaintext, "LEMON")
vigenere_result = crack_vigenere(vigenere_ciphertext, max_key_length=16)
vigenere_metrics = accuracy_metrics(plaintext, vigenere_result["plaintext"])

report = {
    "sample_plaintext_letters": sum(ch.isalpha() for ch in plaintext),
    "caesar": {
        "actual_key": 7,
        "recovered_key": caesar_result["key"],
        "letter_accuracy_percent": caesar_metrics["letter_accuracy"],
        "exact_match": caesar_metrics["exact_match"],
        "chi_square_score": round(caesar_result["score"], 3),
    },
    "vigenere": {
        "actual_key": "LEMON",
        "recovered_key": vigenere_result["key"],
        "estimated_key_length": vigenere_result["key_length"],
        "letter_accuracy_percent": vigenere_metrics["letter_accuracy"],
        "exact_match": vigenere_metrics["exact_match"],
        "chi_square_score": round(vigenere_result["score"], 3),
    },
}
output = project_root / "results" / "accuracy_results.json"
output.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
print(f"\nSaved results to: {output}")
