# MINI PROJECT REPORT
## Automated Cryptanalysis of Caesar & Vigenere Ciphers

**Project Code:** CSL-G02  
**Course/Lab:** Cyber Security Lab (7CS4-22)  
**Student:** Riya Agrawal  
**Institute:** Swami Keshvanand Institute of Technology, Management & Gramothan, Jaipur  
**Session:** 2026-27

---

## 1. Abstract
Cryptanalysis is the study of techniques used to examine encrypted information and recover
the original message without being given the secret key. This project implements automated
cryptanalysis for two classical ciphers: Caesar and Vigenere. It uses English letter-frequency
statistics and chi-square scoring to rank possible plaintexts. For Vigenere, it also uses
Kasiski examination to suggest a likely repeating-key length. The program provides encryption,
decryption, automatic key recovery, and a simple accuracy evaluation facility.

## 2. Problem statement
To develop a beginner-friendly Python application that attempts to break Caesar and Vigenere
ciphertext using letter-frequency analysis, chi-square scoring and Kasiski examination, and
reports recovery accuracy on sample texts.

## 3. Objectives
1. Understand Caesar and Vigenere encryption.
2. Implement encryption and decryption for both ciphers.
3. Use English letter-frequency information to evaluate candidate plaintexts.
4. Apply chi-square scoring to select likely Caesar shifts and Vigenere column shifts.
5. Use Kasiski examination to estimate a possible Vigenere key length.
6. Evaluate recovered plaintext against known sample plaintext.

## 4. Tools and technologies
- Programming language: Python
- Editor: Visual Studio Code (recommended)
- Python modules: `collections`, `argparse`, `pathlib`, `re`
- Testing: `pytest` (optional)

## 5. Background and theory

### 5.1 Caesar cipher
The Caesar cipher shifts each alphabetic character by a fixed key value.
For encryption: `C = (P + K) mod 26`  
For decryption: `P = (C - K) mod 26`  
Here, P is the plaintext letter number, C is the ciphertext letter number and K is the shift.

Since there are only 26 possible shifts, an attacker can try every shift. The program decrypts
the ciphertext with all 26 keys and scores each result.

### 5.2 Vigenere cipher
The Vigenere cipher uses a repeating keyword. Each keyword letter determines the shift applied
to the corresponding plaintext letter.
For encryption: `C[i] = (P[i] + K[i]) mod 26`  
For decryption: `P[i] = (C[i] - K[i]) mod 26`  
The keyword repeats until all letters have been processed. Spaces and punctuation are preserved
and do not consume a key character.

### 5.3 Letter-frequency analysis
Natural English text does not use every letter equally often. For example, E, T, A and O
usually occur more often than J, Q, X and Z. The program compares candidate plaintext letter
counts with a standard English frequency table.

### 5.4 Chi-square scoring
The chi-square statistic measures the difference between observed and expected letter counts:

`X² = Σ ((Observed - Expected)² / Expected)`

A lower score means that the candidate's letter distribution is closer to the reference English
distribution. A low score is evidence, not proof, that a candidate is correct.

### 5.5 Kasiski examination
The Kasiski method looks for repeated groups of letters in Vigenere ciphertext. It measures
the distances between repeated groups and checks their common factors. Those factors can
suggest the length of the repeating key. This is a clue rather than a guarantee.

## 6. System design / workflow
1. User supplies ciphertext and selects Caesar or Vigenere.
2. The program removes non-alphabetic characters only for statistical calculations.
3. For Caesar, it tests all 26 shifts.
4. For Vigenere, it estimates key length using repeated n-gram distances and average
   index of coincidence, then solves each key-position column using chi-square scoring.
5. The program decrypts the text using the selected/recovered key.
6. If the original plaintext is available, letter accuracy and exact-match status can be
   calculated.

## 7. Modules
- `caesar_encrypt()` / `caesar_decrypt()`: Caesar cipher operations.
- `vigenere_encrypt()` / `vigenere_decrypt()`: Vigenere cipher operations.
- `chi_squared()`: scores a candidate against English letter frequencies.
- `crack_caesar()`: tries every Caesar shift and returns the best-scoring result.
- `kasiski_distances()`: finds distances between repeated ciphertext groups.
- `estimate_vigenere_key_length()`: ranks possible key lengths using Kasiski votes and IC.
- `crack_vigenere()`: recovers a repeating key and decrypts the ciphertext.
- `accuracy_metrics()`: compares recovered letters with known plaintext.

## 8. Testing and accuracy
The automated test file checks:
- Caesar encryption/decryption round trip.
- Vigenere encryption/decryption round trip.
- Automatic Caesar key recovery on a longer English sample.
- Vigenere key recovery when the key length is supplied.

For a reproducible accuracy experiment, run `python src/evaluate.py`. It encrypts the bundled
sample with Caesar shift 7 and Vigenere keyword LEMON, runs automatic cracking, compares the
recovered letters with the original, and writes the measurements to
`results/accuracy_results.json`.

### Observed result on the bundled sample
| Cipher | Actual key | Recovered key | Estimated key length | Letter accuracy | Exact match |
|---|---:|---:|---:|---:|---|
| Caesar | 7 | 7 | — | 100.00% | Yes |
| Vigenere | LEMON | LEMON | 5 | 100.00% | Yes |

These are results for the bundled sample only, not a guarantee for every ciphertext. Automatic
Vigenere key-length estimation is heuristic and can fail on short or unusual text.
Do not claim 100% automatic Vigenere recovery unless your own run demonstrates it.

## 9. Result discussion
The project demonstrates that Caesar is particularly weak because its small key space can be
searched exhaustively. Vigenere is more difficult because different alphabet shifts are applied
through a repeating key. Frequency analysis becomes useful after the ciphertext is separated
into key-position columns. Kasiski examination can help estimate the key length when repeated
patterns exist.

## 10. Limitations
- The statistical model is designed for English text.
- Short messages may not follow normal English frequency patterns.
- Kasiski examination requires repeated sequences and may not identify a useful key length.
- The Vigenere cracking method is educational and heuristic; it is not guaranteed to recover
  every key or plaintext.
- These classical ciphers are not suitable for protecting modern sensitive information.

## 11. Conclusion
The mini project implements encryption, decryption and automated cryptanalysis for Caesar
and Vigenere ciphers. It demonstrates how letter-frequency analysis, chi-square scoring and
Kasiski examination can be used to study weaknesses in classical encryption. Testing with
known plaintext makes it possible to measure recovery accuracy and understand the limits of
statistical attacks.

## 12. Future scope
- Try multiple candidate key lengths and rank complete plaintext candidates.
- Add n-gram language scoring for more accurate Vigenere recovery.
- Add a graphical user interface.
- Export experiment results to CSV.
- Test on multiple text lengths and different English writing styles.

## 13. References
1. William Stallings, *Cryptography and Network Security: Principles and Practice*.
2. The standard English letter-frequency distribution used in classical cryptanalysis.
3. Python documentation: https://docs.python.org/3/
